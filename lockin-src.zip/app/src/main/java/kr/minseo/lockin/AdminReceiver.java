package kr.minseo.lockin;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/** 켜 두면 기기 관리자를 먼저 꺼야만 앱을 지울 수 있음 (그 화면은 비밀번호로 막힘) */
public class AdminReceiver extends DeviceAdminReceiver {
    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "끄면 LockIn을 지울 수 있게 돼요.";
    }
}
