package kr.minseo.lockin;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 폰·패드 동기화 (Firebase 로그인 + Firestore, 라이브러리 없이 REST로)
 * 문서 위치: lockin/{uid}
 *   blocked  : 차단 앱 목록
 *   pinHash  : 비밀번호(암호화된 값)
 *   cfgAt    : 위 둘을 마지막으로 바꾼 시각
 *   u_{기기} : {day, ms} 기기별 오늘 유튜브 시간 → 전부 더해서 30분
 */
public final class Sync {
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static volatile long lastRun = 0;
    private static volatile long serverOff = Long.MIN_VALUE;   // 서버 시각 - 폰 시각

    public interface Done { void done(boolean ok, String msg); }

    /** 주기적으로 부름 (force면 바로) */
    public static void kick(Context c, boolean force) {
        if (!Config.ready()) return;
        final Store st = Store.get(c);
        if (!st.loggedIn()) return;
        long now = System.currentTimeMillis();
        if (!force && now - lastRun < 55_000) return;
        lastRun = now;
        EX.execute(() -> {
            try { run(st); } catch (Exception ignored) { }
        });
    }

    /** 구글 ID 토큰으로 Firebase 로그인 → 첫 동기화 */
    public static void login(Context c, String googleIdToken, Done cb) {
        final Store st = Store.get(c);
        EX.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("postBody", "id_token=" + URLEncoder.encode(googleIdToken, "UTF-8") + "&providerId=google.com");
                body.put("requestUri", "http://localhost");
                body.put("returnIdpCredential", true);
                body.put("returnSecureToken", true);
                JSONObject r = new JSONObject(http("POST",
                        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=" + Config.API_KEY,
                        body.toString(), "application/json", null));
                long exp = System.currentTimeMillis() + Long.parseLong(r.optString("expiresIn", "3600")) * 1000L;
                st.setTokens(r.getString("idToken"), r.getString("refreshToken"), exp);
                st.setAccount(r.getString("localId"), r.optString("email", ""));
                st.setName(r.optString("displayName", ""));
                run(st);
                lastRun = System.currentTimeMillis();
                cb.done(true, st.email());
            } catch (Exception e) {
                cb.done(false, String.valueOf(e.getMessage()));
            }
        });
    }

    private static String token(Store st) throws Exception {
        if (System.currentTimeMillis() < st.idExp() - 60_000 && !st.idToken().isEmpty()) return st.idToken();
        String form = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(st.refreshToken(), "UTF-8");
        JSONObject r = new JSONObject(http("POST", "https://securetoken.googleapis.com/v1/token?key=" + Config.API_KEY,
                form, "application/x-www-form-urlencoded", null));
        long exp = System.currentTimeMillis() + Long.parseLong(r.optString("expires_in", "3600")) * 1000L;
        st.setTokens(r.getString("id_token"), r.getString("refresh_token"), exp);
        return r.getString("id_token");
    }

    private static synchronized void run(Store st) throws Exception {
        String tok = token(st);
        if (serverOff != Long.MIN_VALUE) st.setServerOffset(serverOff);
        String doc = "https://firestore.googleapis.com/v1/projects/" + Config.PROJECT_ID
                + "/databases/(default)/documents/lockin/" + st.uid();
        String myKey = "u_" + st.devId();
        String today = Store.today();

        // 1) 받아오기
        JSONObject fields = null;
        try {
            fields = new JSONObject(http("GET", doc, null, null, tok)).optJSONObject("fields");
        } catch (NotFound nf) {
            fields = null;
        }
        boolean first = st.firstSync();
        boolean remoteHasCfg = fields != null && fields.has("cfgAt");
        if (remoteHasCfg) {
            long rAt = Long.parseLong(fields.getJSONObject("cfgAt").optString("integerValue", "0"));
            if (first || (!st.cfgDirty() && rAt > st.cfgAt())) {
                Set<String> b = new HashSet<>();
                JSONArray vals = fields.optJSONObject("blocked") == null ? null
                        : fields.getJSONObject("blocked").optJSONObject("arrayValue") == null ? null
                        : fields.getJSONObject("blocked").getJSONObject("arrayValue").optJSONArray("values");
                if (vals != null) for (int i = 0; i < vals.length(); i++) b.add(vals.getJSONObject(i).optString("stringValue"));
                String ph = fields.optJSONObject("pinHash") == null ? null : fields.getJSONObject("pinHash").optString("stringValue");
                st.applyRemote(b, ph, rAt);
            }
        }
        long others = 0;
        if (fields != null) {
            Iterator<String> it = fields.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (!k.startsWith("u_") || k.equals(myKey)) continue;
                JSONObject m = fields.getJSONObject(k).optJSONObject("mapValue");
                if (m == null || m.optJSONObject("fields") == null) continue;
                JSONObject f = m.getJSONObject("fields");
                String d = f.optJSONObject("day") == null ? "" : f.getJSONObject("day").optString("stringValue");
                if (!today.equals(d)) continue;
                others += Long.parseLong(f.getJSONObject("ms").optString("integerValue", "0"));
            }
        }
        st.setOthers(today, others);

        // 2) 올리기: 내 시간 + (바뀌었으면) 설정
        JSONObject out = new JSONObject();
        List<String> mask = new ArrayList<>();
        JSONObject mine = new JSONObject().put("mapValue", new JSONObject().put("fields", new JSONObject()
                .put("day", new JSONObject().put("stringValue", today))
                .put("ms", new JSONObject().put("integerValue", String.valueOf(st.myUsedMs())))));
        out.put(myKey, mine);
        mask.add(myKey);
        boolean pushCfg = st.cfgDirty() || !remoteHasCfg;
        if (first && remoteHasCfg) pushCfg = false;
        if (pushCfg && st.hasPin()) {
            JSONArray arr = new JSONArray();
            for (String p : st.blocked()) arr.put(new JSONObject().put("stringValue", p));
            out.put("blocked", new JSONObject().put("arrayValue", new JSONObject().put("values", arr)));
            out.put("pinHash", new JSONObject().put("stringValue", st.pinHash()));
            long at = st.cfgAt() == 0 ? System.currentTimeMillis() : st.cfgAt();
            out.put("cfgAt", new JSONObject().put("integerValue", String.valueOf(at)));
            mask.add("blocked");
            mask.add("pinHash");
            mask.add("cfgAt");
        }
        StringBuilder q = new StringBuilder();
        for (String m : mask) q.append(q.length() == 0 ? "?" : "&").append("updateMask.fieldPaths=").append(m);
        http("PATCH", doc + q, new JSONObject().put("fields", out).toString(), "application/json", tok);
        if (serverOff != Long.MIN_VALUE) st.setServerOffset(serverOff);
        if (pushCfg) st.clearCfgDirty();
        st.setFirstSync(false);
        st.setLastSync(System.currentTimeMillis());
    }

    static final class NotFound extends Exception {
        private static final long serialVersionUID = 1L;
    }

    private static String http(String method, String url, String body, String type, String bearer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10_000);
        c.setReadTimeout(15_000);
        if ("PATCH".equals(method)) {               // 안드로이드 HttpURLConnection은 PATCH를 직접 못 써서
            c.setRequestMethod("POST");
            c.setRequestProperty("X-HTTP-Method-Override", "PATCH");
        } else {
            c.setRequestMethod(method);
        }
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
        c.setRequestProperty("X-Android-Package", Config.PACKAGE);
        c.setRequestProperty("X-Android-Cert", Config.CERT_SHA1);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", type);
            try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
        }
        int code = c.getResponseCode();
        long d = c.getHeaderFieldDate("Date", 0);
        if (d > 0) serverOff = d - System.currentTimeMillis();
        InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
        String res = "";
        if (in != null) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            res = bo.toString("UTF-8");
            in.close();
        }
        c.disconnect();
        if (code == 404) throw new NotFound();
        if (code >= 400) throw new Exception("HTTP " + code + " " + res);
        return res;
    }
}
