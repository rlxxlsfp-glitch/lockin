package kr.minseo.lockin;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

/** 막힌 앱을 열었을 때 덮는 잠금 화면 */
public class LockActivity extends Activity {
    private WebView web;
    private String type = "block", name = "이 앱";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        read(getIntent());
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.setBackgroundColor(isDark() ? Color.parseColor("#0f0f14") : Color.WHITE);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        paintBars();
        web.loadUrl("file:///android_asset/lock.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        read(intent);
        web.loadUrl("file:///android_asset/lock.html");
    }

    private void read(Intent i) {
        if (i == null) return;
        if (i.getStringExtra("type") != null) type = i.getStringExtra("type");
        if (i.getStringExtra("name") != null) name = i.getStringExtra("name");
    }

    @Override
    public void onBackPressed() { goHome(); }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
        finish();
    }

    private boolean isDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    @SuppressWarnings("deprecation")
    private void paintBars() {
        Window w = getWindow();
        boolean dark = isDark();
        int bg = dark ? Color.parseColor("#0f0f14") : Color.WHITE;
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        w.getDecorView().setSystemUiVisibility(dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
    }

    class Bridge {
        @JavascriptInterface
        public String type() { return type; }

        @JavascriptInterface
        public String name() { return name; }

        @JavascriptInterface
        public boolean isDark() { return LockActivity.this.isDark(); }

        @JavascriptInterface
        public void home() { runOnUiThread(LockActivity.this::goHome); }

        @JavascriptInterface
        public boolean unlock(String pin) {
            Store st = Store.get(LockActivity.this);
            if (!st.checkPin(pin)) return false;
            st.grantPass(3 * 60_000);
            runOnUiThread(LockActivity.this::finish);
            return true;
        }
    }
}
