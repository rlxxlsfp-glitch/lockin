package kr.minseo.lockin;

import android.app.Activity;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private Store st;
    private boolean cameBack = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = Store.get(this);
        Crash.install(this);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setBackgroundColor(isDark() ? Color.parseColor("#0f0f14") : Color.WHITE);
        web.addJavascriptInterface(new Bridge(), "Android");
        // 메모리가 부족해서 화면(웹뷰)이 죽어도 앱 전체(잠금 서비스 포함)가 같이 죽지 않게
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Crash.note(MainActivity.this, "화면 다시 그림");
                recreate();
                return true;
            }
        });
        setContentView(web);
        paintBars();
        web.loadUrl("file:///android_asset/index.html");
        // 알림창에 유튜브 남은 시간을 띄우려면 알림 권한이 필요 (안드로이드 13 이상)
        if (android.os.Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
            getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("askedNotif", true).apply();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        web.evaluateJavascript("window.onResumeApp&&onResumeApp()", null);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        cameBack = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        paintBars();
        web.evaluateJavascript("window.onResumeApp&&onResumeApp()", null);
        Sync.kick(this, true);
        if (cameBack) {
            cameBack = false;
            web.evaluateJavascript("window.onOpenApp&&onOpenApp()", null);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){var d=document.getElementById('drawer');if(d&&d.classList.contains('show')){closeMenu();return 1}var s=document.getElementById('sheet');if(s&&s.classList.contains('show')){closePin();return 1}if(typeof cur!=='undefined'&&cur==='pick'){go('main',true);return 1}return 0})()", v -> {
            if (!"1".equals(v)) MainActivity.super.onBackPressed();
        });
    }

    private boolean isDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    @SuppressWarnings("deprecation")
    private void paintBars() {
        Window w = getWindow();
        boolean dark = isDark();
        int bg = dark ? Color.parseColor("#0f0f14") : Color.WHITE;
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        int flags = 0;
        if (!dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private boolean accessibilityOn() {
        if (LockService.running) return true;
        String on = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (on == null) return false;
        String me = new ComponentName(this, LockService.class).flattenToString();
        String meShort = new ComponentName(this, LockService.class).flattenToShortString();
        return on.contains(me) || on.contains(meShort);
    }

    private boolean adminOn() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        return dpm != null && dpm.isAdminActive(new ComponentName(this, AdminReceiver.class));
    }

    private boolean notifOn() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        return nm != null && nm.areNotificationsEnabled();
    }

    /** 안드로이드가 아직 권한 창을 띄워 줄 수 있는지 (두 번 거절하면 못 띄움) */
    private boolean canAskNotif() {
        if (android.os.Build.VERSION.SDK_INT < 33) return false;
        return !getSharedPreferences("ui", MODE_PRIVATE).getBoolean("askedNotif", false)
                || shouldShowRequestPermissionRationale("android.permission.POST_NOTIFICATIONS");
    }

    private boolean batteryFree() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private static String iconData(Drawable d) {
        int size = 96;
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private void loginResult(boolean ok, String msg) {
        final String js = "window.onLogin&&onLogin(" + ok + "," + JSONObject.quote(msg == null ? "" : msg) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    /** 구글 계정 고르기 → ID 토큰 → Firebase 로그인 */
    private void googleLogin() {
        if (!Config.ready()) { loginResult(false, "설정값이 아직 없어요"); return; }
        GetGoogleIdOption opt = new GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(Config.WEB_CLIENT_ID)
                .setAutoSelectEnabled(false)
                .build();
        GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
        CredentialManager cm = CredentialManager.create(this);
        cm.getCredentialAsync(this, req, new CancellationSignal(), Executors.newSingleThreadExecutor(),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(GetCredentialResponse res) {
                        try {
                            Credential c = res.getCredential();
                            if (c instanceof CustomCredential
                                    && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
                                GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(((CustomCredential) c).getData());
                                Sync.login(MainActivity.this, g.getIdToken(), (ok, msg) -> loginResult(ok, msg));
                            } else {
                                loginResult(false, "구글 계정이 아니에요");
                            }
                        } catch (Exception e) {
                            loginResult(false, String.valueOf(e.getMessage()));
                        }
                    }

                    @Override
                    public void onError(GetCredentialException e) {
                        loginResult(false, String.valueOf(e.getMessage()));
                    }
                });
    }

    /** 화면(HTML)에서 부르는 함수들 */
    class Bridge {
        @JavascriptInterface
        public String state() {
            try {
                JSONObject o = new JSONObject();
                o.put("hasPin", st.hasPin());
                o.put("acc", accessibilityOn());
                o.put("admin", adminOn());
                o.put("battery", batteryFree());
                o.put("notif", notifOn());
                o.put("usedMs", st.usedMs());
                o.put("limitMs", Store.LIMIT_MS);
                o.put("blocked", new JSONArray(st.blocked()));
                JSONArray dom = new JSONArray();
                for (String d : Store.SHOWN_DOMAINS) dom.put(d);
                o.put("domains", dom);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void loadApps() {
            new Thread(() -> {
                JSONArray arr = new JSONArray();
                try {
                    PackageManager pm = getPackageManager();
                    Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                    Set<String> seen = new HashSet<>();
                    for (ResolveInfo r : list) {
                        String p = r.activityInfo.packageName;
                        if (!seen.add(p)) continue;
                        ApplicationInfo ai = r.activityInfo.applicationInfo;
                        boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                        @SuppressWarnings("deprecation")
                        boolean flag = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                        JSONObject o = new JSONObject();
                        o.put("p", p);
                        o.put("l", r.loadLabel(pm).toString());
                        o.put("g", !system && (ai.category == ApplicationInfo.CATEGORY_GAME || flag));
                        o.put("i", iconData(r.loadIcon(pm)));
                        arr.put(o);
                    }
                } catch (Exception ignored) { }
                final String js = "window.onApps&&onApps(" + arr.toString() + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }

        @JavascriptInterface
        public void setPin(String pin) { st.setPin(pin); Sync.kick(MainActivity.this, true); }

        @JavascriptInterface
        public String account() {
            try {
                return new JSONObject().put("ready", Config.ready()).put("in", st.loggedIn()).put("email", st.email())
                        .put("name", st.name()).put("last", st.lastSync()).toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void login() { runOnUiThread(MainActivity.this::googleLogin); }

        @JavascriptInterface
        public void logout() { st.logout(); }

        @JavascriptInterface
        public boolean checkPin(String pin) { return st.checkPin(pin); }

        @JavascriptInterface
        public void setBlocked(String json) {
            try {
                JSONArray a = new JSONArray(json);
                Set<String> s = new HashSet<>();
                for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
                st.setBlocked(s);
                Sync.kick(MainActivity.this, true);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void openAccessibility() {
            st.grantPass(5 * 60_000);
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        }

        @JavascriptInterface
        public void openAppInfo() {
            st.grantPass(5 * 60_000);
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void openAdmin() {
            st.grantPass(3 * 60_000);
            runOnUiThread(() -> {
                Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(MainActivity.this, AdminReceiver.class));
                i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "켜 두면 비밀번호 없이 LockIn을 지울 수 없어요.");
                startActivity(i);
            });
        }

        @JavascriptInterface
        @SuppressWarnings("BatteryLife")
        public void openBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            });
        }

        @JavascriptInterface
        public String report() { return Crash.report(MainActivity.this); }

        @JavascriptInterface
        public void copy(String text) {
            runOnUiThread(() -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("LockIn", text));
            });
        }

        @JavascriptInterface
        public boolean canAskNotif() { return MainActivity.this.canAskNotif(); }

        @JavascriptInterface
        public void askNotif() {
            runOnUiThread(() -> {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("askedNotif", true).apply();
            });
        }

        /** 알림 설정 화면 (비밀번호 확인 뒤에만 부름) */
        @JavascriptInterface
        public void openNotifSettings() {
            st.grantPass(2 * 60_000);
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())));
        }

        @JavascriptInterface
        public boolean isDark() { return MainActivity.this.isDark(); }
    }
}
