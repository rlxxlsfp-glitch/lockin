package kr.minseo.lockin;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView web;
    private Store st;
    private boolean cameBack = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = Store.get(this);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setBackgroundColor(isDark() ? Color.parseColor("#0f0f14") : Color.WHITE);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        paintBars();
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        cameBack = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        paintBars();
        web.evaluateJavascript("window.onResumeApp&&onResumeApp()", null);
        if (cameBack) {
            cameBack = false;
            web.evaluateJavascript("window.onOpenApp&&onOpenApp()", null);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){if(typeof cur!=='undefined'&&cur==='pick'){go('main',true);return 1}return 0})()", v -> {
            if (!"1".equals(v)) MainActivity.super.onBackPressed();
        });
    }

    private boolean isDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    @SuppressWarnings("deprecation")
    private void paintBars() {
        Window w = getWindow();
        boolean dark = isDark();
        int bg = dark ? Color.parseColor("#0f0f14") : Color.WHITE;
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        int flags = 0;
        if (!dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private boolean accessibilityOn() {
        if (LockService.running) return true;
        String on = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (on == null) return false;
        String me = new ComponentName(this, LockService.class).flattenToString();
        String meShort = new ComponentName(this, LockService.class).flattenToShortString();
        return on.contains(me) || on.contains(meShort);
    }

    private boolean adminOn() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        return dpm != null && dpm.isAdminActive(new ComponentName(this, AdminReceiver.class));
    }

    private static String iconData(Drawable d) {
        int size = 96;
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    /** 화면(HTML)에서 부르는 함수들 */
    class Bridge {
        @JavascriptInterface
        public String state() {
            try {
                JSONObject o = new JSONObject();
                o.put("hasPin", st.hasPin());
                o.put("acc", accessibilityOn());
                o.put("admin", adminOn());
                o.put("usedMs", st.usedMs());
                o.put("limitMs", Store.LIMIT_MS);
                o.put("blocked", new JSONArray(st.blocked()));
                JSONArray dom = new JSONArray();
                for (String d : Store.SHOWN_DOMAINS) dom.put(d);
                o.put("domains", dom);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void loadApps() {
            new Thread(() -> {
                JSONArray arr = new JSONArray();
                try {
                    PackageManager pm = getPackageManager();
                    Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                    Set<String> seen = new HashSet<>();
                    for (ResolveInfo r : list) {
                        String p = r.activityInfo.packageName;
                        if (!seen.add(p)) continue;
                        ApplicationInfo ai = r.activityInfo.applicationInfo;
                        boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                        @SuppressWarnings("deprecation")
                        boolean flag = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                        JSONObject o = new JSONObject();
                        o.put("p", p);
                        o.put("l", r.loadLabel(pm).toString());
                        o.put("g", !system && (ai.category == ApplicationInfo.CATEGORY_GAME || flag));
                        o.put("i", iconData(r.loadIcon(pm)));
                        arr.put(o);
                    }
                } catch (Exception ignored) { }
                final String js = "window.onApps&&onApps(" + arr.toString() + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }

        @JavascriptInterface
        public void setPin(String pin) { st.setPin(pin); }

        @JavascriptInterface
        public boolean checkPin(String pin) { return st.checkPin(pin); }

        @JavascriptInterface
        public void setBlocked(String json) {
            try {
                JSONArray a = new JSONArray(json);
                Set<String> s = new HashSet<>();
                for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
                st.setBlocked(s);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void openAccessibility() {
            st.grantPass(5 * 60_000);
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        }

        @JavascriptInterface
        public void openAppInfo() {
            st.grantPass(5 * 60_000);
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void openAdmin() {
            st.grantPass(3 * 60_000);
            runOnUiThread(() -> {
                Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(MainActivity.this, AdminReceiver.class));
                i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "켜 두면 비밀번호 없이 LockIn을 지울 수 없어요.");
                startActivity(i);
            });
        }

        @JavascriptInterface
        public boolean isDark() { return MainActivity.this.isDark(); }
    }
}
