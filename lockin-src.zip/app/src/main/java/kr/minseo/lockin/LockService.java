package kr.minseo.lockin;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** 지금 열린 앱을 보고, 막을 앱이면 잠금 화면을 띄우는 서비스 */
public class LockService extends AccessibilityService {
    public static volatile boolean running = false;

    private static final Set<String> BROWSERS = new HashSet<>(Arrays.asList(
            "com.android.chrome", "com.chrome.beta", "com.sec.android.app.sbrowser", "com.sec.android.app.sbrowser.beta",
            "com.nhn.android.search", "com.naver.whale", "org.mozilla.firefox", "com.microsoft.emmx",
            "com.brave.browser", "com.opera.browser", "com.opera.mini.native", "com.google.android.googlequicksearchbox",
            "com.duckduckgo.mobile.android", "com.kiwibrowser.browser"));
    private static final Set<String> GUARD = new HashSet<>(Arrays.asList(
            "com.android.settings", "com.samsung.android.settings", "com.samsung.accessibility",
            "com.google.android.packageinstaller", "com.android.packageinstaller", "com.samsung.android.packageinstaller",
            "com.samsung.android.lool", "com.samsung.android.sm.devicesecurity"));
    /** 들어갈 때마다 비밀번호 (보안 폴더에 차단 앱을 다시 까는 걸 막기) */
    private static final Set<String> PIN_TO_ENTER = new HashSet<>(Arrays.asList(
            "com.samsung.knox.securefolder", "com.samsung.knox.securefolder.switcher"));
    private static final Set<String> NEVER = new HashSet<>(Arrays.asList(
            "com.android.systemui", "android", "com.samsung.android.dialer", "com.google.android.dialer",
            "com.android.dialer", "com.samsung.android.incallui", "com.android.phone"));

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<String, Boolean> gameCache = new HashMap<>();
    private Store st;
    private String curPkg = "", curClass = "";
    private boolean curWeb = false;      // 지금 화면이 (앱 안) 브라우저인지
    private boolean ytWindow = false;    // 분할 화면·팝업으로 유튜브가 떠 있는지
    private long lastPip = 0;
    private boolean ytWeb = false;
    private long lastTick = 0, lastCheck = 0, lastLock = 0;
    private int tickCount = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        st = Store.get(this);
        running = true;
        st.grantPass(90_000); // 켜자마자 설정 화면이 막히지 않게 잠깐 열어 둠
        lastTick = System.currentTimeMillis();
        h.removeCallbacks(tick);
        h.postDelayed(tick, 1000);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        running = false;
        h.removeCallbacks(tick);
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacks(tick);
        super.onDestroy();
    }

    @Override
    public void onInterrupt() { }

    /* 1초마다: 유튜브를 보고 있으면 시간 더하기 */
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            long d = Math.min(Math.max(now - lastTick, 0), 3000);
            lastTick = now;
            st.checkClock();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            boolean screenOn = pm == null || pm.isInteractive();
            if (tickCount++ % 2 == 0) ytWindow = screenOn && youtubeWindowVisible();
            boolean watching = screenOn && (Store.YOUTUBE.equals(curPkg) || (ytWeb && curWeb) || ytWindow);
            if (watching) {
                st.addUsed(d, tickCount % 5 == 0);
                if (st.overLimit()) {
                    st.addUsed(0, true);
                    boolean front = Store.YOUTUBE.equals(curPkg) || (ytWeb && curWeb);
                    if (front || now - lastPip > 5000) {   // 팝업 유튜브는 5초마다만
                        lastPip = now;
                        lock("time", "유튜브");
                    }
                }
            }
            Sync.kick(LockService.this, false);   // 1분마다 폰·패드 시간 맞추기
            h.postDelayed(this, 1000);
        }
    };

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (st == null || e == null || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        int type = e.getEventType();

        if (pkg.equals(getPackageName())) { curPkg = pkg; ytWeb = false; return; }
        if (isKeyboard(pkg) || NEVER.contains(pkg)) return;

        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (!pkg.equals(curPkg)) ytWeb = false;
            curPkg = pkg;
            curClass = e.getClassName() == null ? "" : e.getClassName().toString();
            String lc = curClass.toLowerCase(Locale.ROOT);
            curWeb = BROWSERS.contains(pkg) || lc.contains("browser") || lc.contains("webview")
                    || lc.contains("webactivity") || lc.contains("inapp") || lc.contains("customtab");
            check(pkg, true);
        } else if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && pkg.equals(curPkg)) {
            long now = System.currentTimeMillis();
            if (now - lastCheck < 400) return;   // 너무 자주 검사하지 않기
            lastCheck = now;
            check(pkg, false);
        }
    }

    private void check(String pkg, boolean windowChanged) {
        // 0) 보안 폴더: 들어갈 때마다 비밀번호
        if (PIN_TO_ENTER.contains(pkg)) {
            if (st.hasPin() && !st.passActive()) lock("guard", "보안 폴더");
            return;
        }
        // 1) LockIn 설정·삭제·절전 화면 지키기 (배터리 절전 '제외' 허락 창은 통과)
        if (GUARD.contains(pkg)) {
            if (curClass.contains("RequestIgnoreBatteryOptimizations")) return;
            if (st.hasPin() && !st.passActive() && screenMentionsMe()) lock("guard", "LockIn");
            return;
        }
        // 2) 차단 앱 / 게임
        if (windowChanged || !curWeb) {
            if (st.blocked().contains(pkg) || isGame(pkg)) { lock("block", label(pkg)); return; }
            if (Store.YOUTUBE.equals(pkg) && st.overLimit()) { lock("time", "유튜브"); return; }
        }
        // 3) 브라우저·앱 안 브라우저(카톡·네이버 등) 주소 검사
        if (curWeb) {
            String url = readUrl(BROWSERS.contains(pkg));
            if (url == null) return;
            url = url.toLowerCase(Locale.ROOT);
            ytWeb = has(url, Store.YT_DOMAINS);
            if (has(url, Store.BLOCKED_DOMAINS)) lock("block", siteName(url));
            else if (ytWeb && st.overLimit()) lock("time", "유튜브");
        }
    }

    private static boolean has(String s, String[] keys) {
        for (String k : keys) if (s.contains(k)) return true;
        return false;
    }

    private static String siteName(String url) {
        if (url.contains("instagram")) return "인스타그램";
        if (url.contains("tiktok")) return "틱톡";
        if (url.contains("facebook") || url.contains("fb.com")) return "Facebook";
        if (url.contains("pinterest") || url.contains("pin.it")) return "Pinterest";
        if (url.contains("blog.naver")) return "네이버 블로그";
        if (url.contains("roblox")) return "Roblox";
        return "이 사이트";
    }

    private boolean isKeyboard(String pkg) {
        return pkg.contains("inputmethod") || pkg.contains("honeyboard") || pkg.contains("keyboard");
    }

    private boolean isGame(String pkg) {
        Boolean c = gameCache.get(pkg);
        if (c != null) return c;
        boolean g = false;
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(pkg, 0);
            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            @SuppressWarnings("deprecation")
            boolean flag = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
            g = !system && (ai.category == ApplicationInfo.CATEGORY_GAME || flag);
        } catch (PackageManager.NameNotFoundException ignored) { }
        gameCache.put(pkg, g);
        return g;
    }

    private String label(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return "이 앱";
        }
    }

    /* 화면에 "LockIn" 글자가 보이면 = 내 앱 설정/삭제 화면 */
    private boolean screenMentionsMe() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText("LockIn");
        return found != null && !found.isEmpty();
    }

    /* 브라우저 주소창 글자 읽기 */
    private String readUrl(boolean realBrowser) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        String[] ids = {
                "com.android.chrome:id/url_bar",
                "com.sec.android.app.sbrowser:id/location_bar_edit_text",
                "com.sec.android.app.sbrowser:id/url_bar",
                "com.sec.android.app.sbrowser:id/location_bar_text",
                "com.sec.android.app.sbrowser.beta:id/location_bar_edit_text",
                "com.naver.whale:id/url_bar"
        };
        for (String id : ids) {
            List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(id);
            if (l != null) for (AccessibilityNodeInfo n : l) {
                if (n.getText() != null) return n.getText().toString();
            }
        }
        String byId = findUrlNode(root, 0, new int[]{0});
        if (byId != null) return byId;
        // 앱 안 브라우저: 화면 위쪽(주소·제목 줄)에 있는 '주소처럼 생긴' 글자 모으기
        Rect r = new Rect();
        root.getBoundsInScreen(r);
        int limit = r.top + Math.max(r.height() / 4, 200);
        StringBuilder sb = new StringBuilder();
        collectUrlish(root, 0, new int[]{0}, limit, sb);
        return sb.length() == 0 ? null : sb.toString();
    }

    private void collectUrlish(AccessibilityNodeInfo n, int depth, int[] count, int limitY, StringBuilder sb) {
        if (n == null || depth > 25 || count[0]++ > 400 || sb.length() > 600) return;
        CharSequence t = n.getText();
        if (t == null) t = n.getContentDescription();
        if (t != null) {
            String s = t.toString().trim();
            if (s.length() < 200 && s.indexOf(' ') < 0 && s.indexOf('.') > 0) {
                Rect b = new Rect();
                n.getBoundsInScreen(b);
                if (b.top < limitY) sb.append(s).append(' ');
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) collectUrlish(n.getChild(i), depth + 1, count, limitY, sb);
    }

    private String findUrlNode(AccessibilityNodeInfo n, int depth, int[] count) {
        if (n == null || depth > 25 || count[0]++ > 400) return null;
        String id = n.getViewIdResourceName();
        if (id != null && n.getText() != null) {
            String lid = id.toLowerCase(Locale.ROOT);
            if (lid.contains("url") || lid.contains("address") || lid.contains("location") || lid.contains("omnibox")) {
                return n.getText().toString();
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            String r = findUrlNode(n.getChild(i), depth + 1, count);
            if (r != null) return r;
        }
        return null;
    }

    /* 분할 화면·팝업 화면에 유튜브가 떠 있는지 */
    private boolean youtubeWindowVisible() {
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            if (ws == null) return false;
            for (AccessibilityWindowInfo w : ws) {
                if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                AccessibilityNodeInfo r = w.getRoot();
                if (r != null && r.getPackageName() != null && Store.YOUTUBE.equals(r.getPackageName().toString())) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    /* 잠금 화면 띄우기 */
    private void lock(String type, String name) {
        long now = System.currentTimeMillis();
        if (now - lastLock < 700) return;
        lastLock = now;
        ytWeb = false;
        performGlobalAction(GLOBAL_ACTION_HOME);
        Intent i = new Intent(this, LockActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("type", type);
        i.putExtra("name", name);
        startActivity(i);
    }
}
