package kr.minseo.lockin;

import android.content.Context;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 앱이 죽거나 서비스가 다시 켜질 때 기록 → 더보기에서 확인 (꺼지는 원인 찾기용) */
public final class Crash {
    private static boolean installed = false;

    private static String time() { return new SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(new Date()); }

    public static synchronized void install(Context c) {
        if (installed) return;
        installed = true;
        final Context app = c.getApplicationContext();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {
            save(app, "앱 오류", ex);
            if (prev != null) prev.uncaughtException(th, ex);
        });
    }

    public static void save(Context c, String where, Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            String s = sw.toString();
            if (s.length() > 1500) s = s.substring(0, 1500);
            c.getSharedPreferences("crash", Context.MODE_PRIVATE).edit()
                    .putString("last", time() + " " + where + "\n" + s).commit();
        } catch (Throwable ignored) { }
    }

    /** 서비스가 (다시) 켜진 시각 기록: 몇 번 꺼졌다 켜졌는지 보기 */
    public static void note(Context c, String what) {
        try {
            android.content.SharedPreferences sp = c.getSharedPreferences("crash", Context.MODE_PRIVATE);
            String log = sp.getString("starts", "");
            log = time() + " " + what + "\n" + log;
            if (log.length() > 600) log = log.substring(0, 600);
            sp.edit().putString("starts", log).apply();
        } catch (Throwable ignored) { }
    }

    public static String report(Context c) {
        android.content.SharedPreferences sp = c.getSharedPreferences("crash", Context.MODE_PRIVATE);
        return "[켜진 기록]\n" + sp.getString("starts", "없음") + "\n[마지막 오류]\n" + sp.getString("last", "없음");
    }
}
