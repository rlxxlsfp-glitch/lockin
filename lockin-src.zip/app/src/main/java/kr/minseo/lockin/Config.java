package kr.minseo.lockin;

/**
 * VOCAP Firebase 설정값.
 * 비어 있으면 로그인 버튼이 꺼진 채로 나오고, 잠금 기능은 그대로 다 돼요.
 */
public final class Config {
    /** firebaseConfig 의 apiKey */
    public static final String API_KEY = "";
    /** firebaseConfig 의 projectId */
    public static final String PROJECT_ID = "";
    /** Firebase → Authentication → 로그인 방법 → Google → 웹 클라이언트 ID */
    public static final String WEB_CLIENT_ID = "";

    public static boolean ready() {
        return !API_KEY.isEmpty() && !PROJECT_ID.isEmpty() && !WEB_CLIENT_ID.isEmpty();
    }
}
