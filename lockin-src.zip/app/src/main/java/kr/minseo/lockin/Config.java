package kr.minseo.lockin;

/**
 * VOCAP Firebase 설정값.
 * 비어 있으면 로그인 버튼이 꺼진 채로 나오고, 잠금 기능은 그대로 다 돼요.
 */
public final class Config {
    /** firebaseConfig 의 apiKey */
    public static final String API_KEY = "AIzaSyABEPwErfiu0UO5nPFu5_P0RVRpEM48ltY";
    /** firebaseConfig 의 projectId */
    public static final String PROJECT_ID = "vocap-e3e9e";
    /** Firebase → Authentication → 로그인 방법 → Google → 웹 클라이언트 ID */
    public static final String WEB_CLIENT_ID = "322645613396-4nvasuvfov8hj44snom6na2s1egs7bj6.apps.googleusercontent.com";

    /** 안드로이드 전용 키라서, 요청할 때 "이 앱이 보냈다"는 표시를 같이 붙여야 함 */
    public static final String PACKAGE = "kr.minseo.lockin";
    public static final String CERT_SHA1 = "12A78D2BA946D43BAF41F678FD3792A49AF117FC";

    public static boolean ready() {
        return !API_KEY.isEmpty() && !PROJECT_ID.isEmpty() && !WEB_CLIENT_ID.isEmpty();
    }
}
