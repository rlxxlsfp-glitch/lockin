package kr.minseo.lockin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

/** 앱 설정과 오늘 유튜브 사용 시간을 저장하는 곳 */
public final class Store {
    public static final long LIMIT_MS = 30L * 60 * 1000;          // 유튜브 하루 30분 (폰+패드 합계)
    public static final String YOUTUBE = "com.google.android.youtube";

    public static final String[] DEFAULT_BLOCKED = {
            "com.instagram.android", "com.instagram.lite",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go",
            "com.pinterest", "com.facebook.katana", "com.facebook.lite",
            "com.roblox.client", "com.nhn.android.blog"
    };
    public static final String[] BLOCKED_DOMAINS = {
            "instagram.com", "tiktok.com", "facebook.com", "fb.com", "pinterest.", "pin.it",
            "blog.naver.com", "roblox.com"
    };
    public static final String[] SHOWN_DOMAINS = {
            "instagram.com", "tiktok.com", "facebook.com", "pinterest.com", "blog.naver.com", "roblox.com"
    };
    public static final String[] YT_DOMAINS = {"youtube.com", "youtu.be"};

    private final SharedPreferences sp;

    private Store(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("lockin", Context.MODE_PRIVATE);
        if (!sp.contains("blocked")) {
            sp.edit().putStringSet("blocked", new HashSet<>(Arrays.asList(DEFAULT_BLOCKED))).apply();
        }
        offset = sp.getLong("clockOff", 0);
        if (!sp.contains("devId")) {
            sp.edit().putString("devId", UUID.randomUUID().toString().replace("-", "").substring(0, 12)).apply();
        }
    }

    private static Store inst;

    public static synchronized Store get(Context c) {
        if (inst == null) inst = new Store(c);
        return inst;
    }

    /* ---------- 믿을 수 있는 시계 ----------
       폰 날짜·시간대를 바꿔도 하루가 안 바뀌게:
       1) 한국 시간 고정  2) 시계가 갑자기 튀면 그만큼 되돌림  3) 동기화할 때 서버 시각으로 맞춤 */
    private static final TimeZone KST = TimeZone.getTimeZone("Asia/Seoul");
    private static volatile long offset = 0;
    private long baseWall = 0, baseElapsed = 0;

    public static long now() { return System.currentTimeMillis() + offset; }

    public static String today() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.KOREA);
        f.setTimeZone(KST);
        return f.format(new Date(now()));
    }

    /** 1초마다 부름: 폰 시계를 손으로 바꿨는지 확인 */
    public synchronized void checkClock() {
        long w = System.currentTimeMillis(), e = SystemClock.elapsedRealtime();
        if (baseElapsed == 0 || e < baseElapsed) { baseWall = w; baseElapsed = e; return; }
        long jump = w - (baseWall + (e - baseElapsed));
        if (Math.abs(jump) > 120_000) {
            offset -= jump;
            sp.edit().putLong("clockOff", offset).apply();
        }
        baseWall = w;
        baseElapsed = e;
    }

    /** 서버(구글) 시각과의 차이를 받으면 그걸로 맞춤 (Date 헤더는 초 단위라 1분 넘게 다를 때만) */
    public synchronized void setServerOffset(long off) {
        if (Math.abs(off - offset) > 60_000) {
            offset = off;
            sp.edit().putLong("clockOff", offset).apply();
        }
    }

    public String devId() { return sp.getString("devId", "dev"); }

    /* ---------- 비밀번호 ---------- */
    public static String hash(String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(("lockin:" + pin).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return pin;
        }
    }

    public boolean hasPin() { return sp.getString("pin", null) != null; }

    public String pinHash() { return sp.getString("pin", ""); }

    public void setPin(String pin) {
        sp.edit().putString("pin", hash(pin)).apply();
        touchCfg();
    }

    public boolean checkPin(String pin) {
        String saved = sp.getString("pin", null);
        return saved != null && saved.equals(hash(pin));
    }

    /* ---------- 설정 화면 잠깐 열어 주기 ---------- */
    public void grantPass(long ms) { sp.edit().putLong("passUntil", now() + ms).apply(); }

    public boolean passActive() { return now() < sp.getLong("passUntil", 0); }

    /* ---------- 차단 목록 ---------- */
    public Set<String> blocked() { return new HashSet<>(sp.getStringSet("blocked", new HashSet<String>())); }

    public void setBlocked(Set<String> s) {
        sp.edit().putStringSet("blocked", new HashSet<>(s)).apply();
        touchCfg();
    }

    /* ---------- 동기화용 설정 시각 ---------- */
    private void touchCfg() { sp.edit().putLong("cfgAt", System.currentTimeMillis()).putBoolean("cfgDirty", true).apply(); }

    public long cfgAt() { return sp.getLong("cfgAt", 0); }

    public boolean cfgDirty() { return sp.getBoolean("cfgDirty", false); }

    public void clearCfgDirty() { sp.edit().putBoolean("cfgDirty", false).apply(); }

    /** 다른 기기에서 바뀐 설정 받아오기 (다시 올리지 않음) */
    public void applyRemote(Set<String> blocked, String pinHash, long at) {
        SharedPreferences.Editor e = sp.edit();
        if (blocked != null) e.putStringSet("blocked", new HashSet<>(blocked));
        if (pinHash != null && !pinHash.isEmpty()) e.putString("pin", pinHash);
        e.putLong("cfgAt", at).putBoolean("cfgDirty", false).apply();
    }

    /* ---------- 로그인 정보 ---------- */
    public boolean loggedIn() { return sp.getString("uid", null) != null; }

    public String uid() { return sp.getString("uid", ""); }

    public String email() { return sp.getString("email", ""); }

    public String name() { return sp.getString("name", ""); }

    public void setName(String n) { sp.edit().putString("name", n).apply(); }

    public long lastSync() { return sp.getLong("lastSync", 0); }

    public void setLastSync(long t) { sp.edit().putLong("lastSync", t).apply(); }

    public String refreshToken() { return sp.getString("refresh", ""); }

    public String idToken() { return sp.getString("idToken", ""); }

    public long idExp() { return sp.getLong("idExp", 0); }

    public void setTokens(String idToken, String refresh, long expMs) {
        sp.edit().putString("idToken", idToken).putString("refresh", refresh).putLong("idExp", expMs).apply();
    }

    public void setAccount(String uid, String email) {
        sp.edit().putString("uid", uid).putString("email", email).putBoolean("firstSync", true).apply();
    }

    public boolean firstSync() { return sp.getBoolean("firstSync", false); }

    public void setFirstSync(boolean b) { sp.edit().putBoolean("firstSync", b).apply(); }

    public void logout() {
        sp.edit().remove("uid").remove("email").remove("name").remove("lastSync").remove("refresh").remove("idToken").remove("idExp")
                .remove("othersMs").remove("othersDay").apply();
    }

    /* ---------- 유튜브 시간 ---------- */
    private String day;
    private long used = -1;

    private void loadUsed() {
        String t = today();
        if (used < 0 || !t.equals(day)) {
            day = t;
            used = t.equals(sp.getString("usedDay", "")) ? sp.getLong("usedMs", 0) : 0;
        }
    }

    /** 이 기기에서 오늘 본 시간 */
    public synchronized long myUsedMs() { loadUsed(); return used; }

    public synchronized void addUsed(long ms, boolean save) {
        loadUsed();
        used += ms;
        if (save) sp.edit().putString("usedDay", day).putLong("usedMs", used).apply();
    }

    /** 다른 기기들이 오늘 본 시간 (동기화로 받아옴) */
    public void setOthers(String d, long ms) { sp.edit().putString("othersDay", d).putLong("othersMs", ms).apply(); }

    public long othersMs() { return today().equals(sp.getString("othersDay", "")) ? sp.getLong("othersMs", 0) : 0; }

    /** 폰+패드 합친 오늘 시간 */
    public long usedMs() { return myUsedMs() + othersMs(); }

    public boolean overLimit() { return usedMs() >= LIMIT_MS; }
}
