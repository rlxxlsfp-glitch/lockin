package kr.minseo.lockin;

import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** 앱 설정과 오늘 유튜브 사용 시간을 저장하는 곳 */
public final class Store {
    public static final long LIMIT_MS = 30L * 60 * 1000;          // 유튜브 하루 30분
    public static final String YOUTUBE = "com.google.android.youtube";

    public static final String[] DEFAULT_BLOCKED = {
            "com.instagram.android", "com.instagram.lite",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go",
            "com.pinterest", "com.facebook.katana", "com.facebook.lite",
            "com.roblox.client", "com.nhn.android.blog"
    };
    public static final String[] BLOCKED_DOMAINS = {
            "instagram.com", "tiktok.com", "facebook.com", "fb.com", "pinterest.", "pin.it",
            "blog.naver.com", "roblox.com"
    };
    public static final String[] SHOWN_DOMAINS = {
            "instagram.com", "tiktok.com", "facebook.com", "pinterest.com", "blog.naver.com", "roblox.com"
    };
    public static final String[] YT_DOMAINS = {"youtube.com", "youtu.be"};

    private final SharedPreferences sp;

    private Store(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("lockin", Context.MODE_PRIVATE);
        if (!sp.contains("blocked")) {
            sp.edit().putStringSet("blocked", new HashSet<>(Arrays.asList(DEFAULT_BLOCKED))).apply();
        }
    }

    private static Store inst;

    public static synchronized Store get(Context c) {
        if (inst == null) inst = new Store(c);
        return inst;
    }

    /* ---------- 비밀번호 ---------- */
    private static String hash(String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(("lockin:" + pin).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return pin;
        }
    }

    public boolean hasPin() { return sp.getString("pin", null) != null; }

    public void setPin(String pin) { sp.edit().putString("pin", hash(pin)).apply(); }

    public boolean checkPin(String pin) {
        String saved = sp.getString("pin", null);
        return saved != null && saved.equals(hash(pin));
    }

    /* ---------- 설정 화면 잠깐 열어 주기 ---------- */
    public void grantPass(long ms) { sp.edit().putLong("passUntil", System.currentTimeMillis() + ms).apply(); }

    public boolean passActive() { return System.currentTimeMillis() < sp.getLong("passUntil", 0); }

    /* ---------- 차단 목록 ---------- */
    public Set<String> blocked() { return new HashSet<>(sp.getStringSet("blocked", new HashSet<String>())); }

    public void setBlocked(Set<String> s) { sp.edit().putStringSet("blocked", new HashSet<>(s)).apply(); }

    /* ---------- 유튜브 시간 ---------- */
    private static String today() { return new SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(new Date()); }

    private String day;
    private long used = -1;

    private void loadUsed() {
        String t = today();
        if (used < 0 || !t.equals(day)) {
            day = t;
            used = t.equals(sp.getString("usedDay", "")) ? sp.getLong("usedMs", 0) : 0;
        }
    }

    public synchronized long usedMs() { loadUsed(); return used; }

    public synchronized void addUsed(long ms, boolean save) {
        loadUsed();
        used += ms;
        if (save) sp.edit().putString("usedDay", day).putLong("usedMs", used).apply();
    }

    public boolean overLimit() { return usedMs() >= LIMIT_MS; }
}
